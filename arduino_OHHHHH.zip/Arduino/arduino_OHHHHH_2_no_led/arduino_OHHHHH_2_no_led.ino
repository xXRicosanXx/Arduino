void setup() {			
  Serial.begin(9600);
  pinMode(13, OUTPUT);
}

void loop() {
  int gas_data = analogRead(A0);		//dichiarazione della variabile GAS che il nostro sensore percepisce e lo prende da A0 cioè l'output del sensore
  
  if (gas_data > 230) {
    digitalWrite(13, HIGH);         // attiva il relè
  } 
  else if (gas_data > 85) {
    digitalWrite(13, LOW);
  } 
  else {
    digitalWrite(13, LOW);
  }
  
  Serial.print("Dati Gas: ");
  Serial.println(gas_data);
  delay(200);
}