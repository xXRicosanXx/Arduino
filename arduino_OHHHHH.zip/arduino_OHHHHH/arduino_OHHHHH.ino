void setup() {			
  Serial.begin(9600);					//per stamapare gli output				
  pinMode(7, OUTPUT);
  pinMode(6, OUTPUT);
  pinMode(8, OUTPUT);
}

void loop() {
  int gas_data = analogRead(A0);		//dichiarazione della variabile GAS che il nostro sensore percepisce e lo prende da A0 cioè l'output del sensore
  
  if (gas_data > 230) {
    digitalWrite(13, HIGH);
    digitalWrite(8, HIGH);
    digitalWrite(7, LOW);
    delay(300);
    digitalWrite(13, LOW);
  } 
  else if (gas_data > 85) {
    digitalWrite(6, HIGH);
    digitalWrite(7, LOW);
    digitalWrite(8, LOW);
    delay(150);
    digitalWrite(6, LOW);
  } 
  else {
    digitalWrite(7, HIGH);
    digitalWrite(8, LOW);
  }
  
  Serial.print("Dati Gas: ");
  Serial.println(gas_data);
  delay(300);
}
